<header>
    <nav class="navbar navbar-expand-md sticky" id="navbar">
        <a class="navbar-brand" href="/">Docmerit</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
            <i class="fas fa-bars" style="color: #fff;"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mr-auto">
                <!-- <li class="nav-item active">
                    <a class="nav-link" href="#"><span class="sr-only">(current)</span></a>
                </li> -->
                <!-- <li class="nav-item">
                    <a class="nav-link" href="#"></a>
                </li> -->
                <!-- <li class="nav-item">
                    <a class="nav-link" href="#"></a>
                </li> -->
            </ul>
            <ul class="navbar-nav">
                <?php if(Auth::check()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/profile')); ?>">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link reg" href="<?php echo e(url('/downloads')); ?>">Downlaod</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/upload')); ?>">Uplaods</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link reg" href="<?php echo e(url('/cart')); ?>">Cart
                    
                        <?php if(count(Auth::user()->cart) > 0): ?>
                            ( <?php echo e(count(Auth::user()->cart)); ?> )
                        <?php endif; ?>
                    
                    </a>
                </li>
                <li class="nav-item">
                    <form id="myform_id" action="<?php echo e(route('logout')); ?>" method="post">
                    <?php echo csrf_field(); ?>

                        <a class="nav-link" href="javascript:$('#myform_id').submit();">Logout</a>
                    
                    </form>
                </li>
                <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/login')); ?>">Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link reg" href="<?php echo e(url('/register')); ?>">Register</a>
                </li>
                    
                <?php endif; ?>
            </ul>
        </div>
    </nav>
</header><?php /**PATH C:\wamp64\www\khasru\khasru\resources\views/frontend/layouts/nav.blade.php ENDPATH**/ ?>