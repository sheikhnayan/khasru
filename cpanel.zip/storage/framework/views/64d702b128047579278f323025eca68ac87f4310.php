
<?php $__env->startSection('header'); ?>

<style>
  .card{
    width: 100%;
    height: auto;
  }
</style>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<body>
  <?php echo $__env->make('frontend.layouts.navmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
  <div class="row justify-content-center mt-10 mb-10">
    <div class="col-md-8">
      <h2 style="font-size: 25px; font-weight:bold">Your Downlaods</h2>
      <table class="table table-bordered mt-20 mb-20">
        <?php
          $data = Auth::user()->documents;
        ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <?php echo e($item->title); ?>

              </td>
              <td>
                <?php echo e($item->category->name); ?>

              </td>
              <td>
                <?php echo e($item->seller->name); ?> 
              </td>
              <td>
                <a href="<?php echo e(route('product',[$item->id])); ?>" class="btn btn-primary">View</a>
                <a href="<?php echo e(route('download',[$item->id])); ?>" target="_blank" class="btn btn-success">Downlaod</a>
              </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
    </div>
  </div>
</div>

</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\khasru\khasru\resources\views/frontend/downloads.blade.php ENDPATH**/ ?>