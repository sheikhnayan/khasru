
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('header'); ?>
    <style>
        .card{
            width: 100%;
        }
        .checked {
            color: orange;
        }
    </style>
<?php $__env->stopSection(); ?>
<body>
    <?php echo $__env->make('frontend.layouts.navmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section id="second-page-header">
        <div class="container">
            <div class="row">
                <div class="col">


                    <div class="header-button">
                        <button>
                            Browse Study Resource | <i class="fa fa-book" aria-hidden="true"></i>  Subjects
    
                        </button>
                    </div> 
    
                        <div class="dropdown">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col col-md-6">
                                            <div class="right-dropdown">

                                                <ul>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                </ul>
                                            </div>
                                        </div>

                                        <div class="col col-md-6">
                                            <div class="left-dropdown">

                                                <ul>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                </ul>
                                            </div>
                                        </div>


                                    </div>
                                </div>
                                <div class="dropdown-footer">
                                    <div class="row">
                                        <div class="col col-md-6">

                                            <a href="#"><i class="fa fa-long-arrow-right" aria-hidden="true"></i> Accounting</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>


                
            </div>
        </div>
    </section>

    <section id="2ndpage">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col col-lg-8">
                    <div class="first-card">
                        <div class="card">
                            <div class="card-body">
                                <h1><?php echo e($data->category->name); ?></h1>
                                <h1><?php echo e($data->title); ?></h1>
                                <p><?php echo e($data->description); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="third-card">
                        <div class="card">
                            <div class="card-header">
                                <p>Preview 6 out of 392 pages</p>
                            </div>
                            <div class="card-body">
                                <iframe src="https://view.officeapps.live.com/op/view.aspx?src=<?php echo e('127.0.0.1:8000/'.str_replace('public','storage',$file->file)); ?>" frameborder="0" style="width:100%;min-height:640px;"></iframe>
                                
                            </div>
                            <div class="card-footer">
                                <p> <i class="fa fa-copyright" aria-hidden="true"></i> Report Copyright Violation</p>
                            </div>
                        </div>
                    </div>

                    <div class="forth-card">
                        <div class="card">
                            <div class="card-header">
                                <p><i class="fa fa-star kopzwart-grey" aria-hidden="true"></i>Reviews [0]</p>
                            </div>
                            <div class="card-body">
                               <div class="card-row">
                                <p>

                                    No review posted yet
                                </p>

                               </div>
                            </div>
                            
                        </div>
                    </div>

                </div>

                <div class="col col-lg-4">
                    <div class="second-card">
                        <div class="card">
                            <div class="card-body">
                                <h1><?php echo e($data->category->name); ?> Details</h1>
                                <?php
                                    $rating = $data->rating->count();
                                ?>
                                <p class="preview-page-review">
                                    <?php if($rating > 0): ?>
                                    <span class="fa fa-star checked"></span>
                                    <?php else: ?>
                                    <span class="fa fa-star"></span>
                                    <?php endif; ?>
                                    <?php if($rating > 1): ?>
                                    <span class="fa fa-star checked"></span>
                                    <?php else: ?> 
                                    <span class="fa fa-star"></span>
                                    <?php endif; ?>
                                    <?php if($rating > 2): ?>
                                    <span class="fa fa-star checked"></span>
                                    <?php else: ?>
                                    <span class="fa fa-star"></span>
                                    <?php endif; ?>
                                    <?php if($rating > 3): ?>
                                    <span class="fa fa-star checked"></span>
                                    <?php else: ?>
                                    <span class="fa fa-star"></span>
                                    <?php endif; ?>
                                    <?php if($rating > 4): ?>
                                    <span class="fa fa-star checked"></span>
                                    <?php else: ?>
                                    <span class="fa fa-star"></span>
                                    <?php endif; ?>
                                </p>
                                <strong class="price-preview">$<?php echo e($data->price); ?></strong>
                                <p>

                                    <a href="<?php echo e(route('addtocart',[$data->id])); ?>" class="btn btn-primary" style="color: #fff"> <i class="fa fa-heart-o" aria-hidden="true"></i> Add to Cart</a>
                                    <p class="terms">
                                        <ul>
                                            <li>
                                                <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                                Trusted by 40,000+ Students
                                            </li>
                                            <li>
                                                <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                                Money Back Guarantee 24/7
                                            </li>
                                            <li>
                                                <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                                Download is directly available
                                            </li>
                                        </ul>
                                    </p>
                                </p>

                                <div class="text-muted">
                                    <div class="row justify-content-center">
                                        <div class="col col-md-4">

                                            <p class="footer-preview">
                                                <span>
                                                    7
                                                    <i class="fa fa-eye ck" aria-hidden="true"></i>
                                                </span>
                                            </p>
                                        </div>
                                        <div class="col col-md-4">

                                            <p class="footer-preview">
                                                <span>
                                                    0
                                                    <i class="fa fa-download ck" aria-hidden="true"></i>
                                                </span>
                                            </p>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="fifth-card">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="preview-title">Specifications</h5>
                            </div>
                            <div class="card-body">
                                <div class="list-doker">
                                    <p class="card-text"></p>
                                    <div class="row">
                                        <div class="col col-md-6">
                                            institution
                                        </div>
                                        <div class="col col-md-6">
                                            <a href=""><?php echo e($data->institute->name); ?> </a>
                                        </div>
                                    </div>
                                    <p class="card-text"></p>
                                    <div class="row">
                                        <div class="col col-md-6">
                                            Study
                                        </div>
                                        <div class="col col-md-6">
                                            <a href=""><?php echo e($data->category->name); ?> </a>
                                        </div>
                                    </div>
                                    
                                    <p class="card-text"></p>
                                    <p class="card-text col-sm-12" style="font-weight: bold">Document</p>
                                    <div class="row">
                                        <div class="col col-md-6">
                                            Language
                                        </div>
                                        <div class="col col-md-6">
                                            <a href=""><?php echo e($data->language); ?> </a>
                                        </div>
                                    </div>
                                    <p class="card-text"></p>
                                    <div class="row">
                                        <div class="col col-md-6">
                                            Subject
                                        </div>
                                        <div class="col col-md-6">
                                            <a href=""><?php echo e($data->subject->name); ?></a>
                                        </div>
                                    </div>
                                    <p class="card-text"></p>
                                    <div class="row">
                                        <div class="col col-md-6">
                                            Updated On
                                        </div>
                                        <div class="col col-md-6">
                                            
                                            <?php echo e(Carbon\Carbon::parse($data->updated_at)->format('M d,Y')); ?>

                                        </div>
                                    </div>
                                    <p class="card-text"></p>
                                    
                                    <div class="row">
                                        <div class="col col-md-6">
                                            Written
                                        </div>
                                        <div class="col col-md-6">
                                            <a href=""><?php echo e($data->year); ?></a>
                                        </div>
                                    </div>
                                    <p class="card-text"></p>
                                </div>
                            </div>
                            
                        </div>
                    </div>

                    <div class="sixth-card">
                        <div class="card">
                            <div class="card-header">
                                <h5>Seller Details</h5>
                            </div>
                            <div class="card-body">
                                <div class="seller-info">
                                    <div class="row">
                                        
                                        <div class="col-md-12 col-12">
                                            <p class="username-preview"><?php echo e($data->seller->name); ?></p>
                                            <?php
                                                $total = DB::table('documents')->where('user_id',$data->user_id)->count();
                                            ?>
                                            <p class="dese-preview"><?php echo e($total); ?> documents uploaded</p>
                                            <p class="dese-preview">28 documents sold</p>
                                            


                                                
                                            
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <p> <i class="fa fa-copyright" aria-hidden="true"></i> Report Copyright Violation</p>
                            </div>
                        </div>
                    </div>


                </div>


            </div>
        </div>
    </section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\khasru\khasru\resources\views/frontend/product.blade.php ENDPATH**/ ?>