
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('header'); ?>

<style>
  .card{
    width: 100%;
    height: auto;
  }
</style>
    
<?php $__env->stopSection(); ?>

<body>
  <?php echo $__env->make('frontend.layouts.navmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
  <div class="row justify-content-center mt-10 mb-10">
    <div class="col-md-8">
      <div class="row">
        <div class="col-md-5">
          <div class="card">
            <i class="fas fa-upload"></i> <?php echo e(count(Auth::user()->documents)); ?>

            Upload
          </div>          
        </div>
        <div class="col-md-5">
          <div class="card">
            <i class="fas fa-download"></i> <?php echo e(count(Auth::user()->orders)); ?>

            Download
          </div>          
        </div>
        <div class="col-md-10 mt-10">
          <div class="card">
            <div class="card-header">
              Increase your sales in just a few steps
            </div>
            <div class="card-body">
              To maximise your sales, share your document on Facebook and Twitter.
We found that promoting your documents on Facebook and Twitter increases sales of your documents up to 10 times. The best sellers on Docmerit put packages of study materials together, and sell these as bundles.You can do this by combining documents in a separate bundle for one fixed fee. 
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\khasru\khasru\resources\views/frontend/profile.blade.php ENDPATH**/ ?>