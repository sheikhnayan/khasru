
<?php $__env->startSection('content'); ?>
    <body>
        <?php echo $__env->make('frontend.layouts.navmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-5 ml-auto mr-auto">
                    <?php if(Session::has('message')): ?>
                        <div class="alert alert-success text-center"><?php echo e(Session::get('message')); ?></div>
                    <?php endif; ?>
                    <?php if(Session::has('error')): ?>
                        <div class="alert alert-danger text-center"><?php echo e(Session::get('error')); ?></div>
                    <?php endif; ?>
                    <p class="category" style="font-weight: bold; font-size: 20px; padding: 10px;">Shopping Cart</p>
                    <div class="card">
                      <div class="card-body">
                        <ul>
                            <?php if(count($data) > 0): ?>
                            <?php
                                $total = 0;
                            ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $total += $item->document->price;
                                ?>
                            <li class="mt-3 mb-3" style="display: block; border: 1px solid black; padding: 12px;">
                                <h4 style="display: inline-block; padding: 0px 20px;">Title: <?php echo e($item->document->title); ?></h4>
                                <h5 style="display: inline-block; padding: 0px 20px;">Category: <?php echo e($item->document->category->name); ?></h5>
                                <h5 style="display: inline-block; padding: 0px 20px;">Price: $<?php echo e($item->document->price); ?></h5>
    
                                <a href="<?php echo e(route('removefromcart',[$item->id])); ?>"> <i class="fas fa-trash-alt" style="display: inline-block; padding: 0px 20px; color: red;"></i> </a> 
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            <?php else: ?>
                                Nothing! 
                                Visit <a href="#">Shop</a>
                            <?php endif; ?>
    
                            <li class="mt-3 mb-3" style="display: block; border: 1px solid black; padding: 12px;">
                                <h4 style="display: inline-block; padding: 0px 20px;">Grand Total: $<?php echo e($total); ?></h4> 
                            </li>
                        </ul>
                      </div>
                    </div>
                    <!-- End Tabs on plain Card -->
                </div>

                <div class="col-md-5 ml-auto mr-auto">
                    <p class="category" style="font-weight: bold; font-size: 20px; padding: 10px;">Choose your payment method</p>
                    <div class="card">
                      <div class="card-body">
                        <ul>
                            <form action="<?php echo e(route('payment')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="amount" value="<?php echo e($total); ?>">

                                <li class="mt-3 mb-3" style="display: block; border: 1px solid black; padding: 12px;">
                                    <input type="radio"  name="paypal" id="paypal">
                                    <label for="paypal">Paypal</label>
                                </li>
        
                                <li class="mt-3 mb-3" style="display: block; padding: 12px;">
                                    <button type="submit" class="btn btn-success">
                                        Pay Now ($<?php echo e($total); ?>)
                                    </button>
                                </li>
                            </form>
                        </ul>
                      </div>
                    </div>
                    <!-- End Tabs on plain Card -->
                </div>
            </div>
        </div>
    </body>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\khasru\khasru\resources\views/frontend/cart.blade.php ENDPATH**/ ?>