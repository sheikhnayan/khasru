<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FrontendController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
##Forntend Routes
Route::get('/',[FrontendController::class,'index']);

Route::get('/product',[FrontendController::class,'product']);

Route::get('/subjects',[FrontendController::class,'subjects']);

Route::get('/subject',[FrontendController::class,'subject']);

Route::get('/selling',[FrontendController::class,'selling']);

Route::get('/sell_1',[FrontendController::class,'sell_1']);

Route::post('/sell_1_store',[FrontendController::class,'sell_1_store'])->name('selling_1');

Route::get('/sell_2/{id}',[FrontendController::class,'sell_2'])->name('sell_2');

Route::post('/sell_2_store/{id}',[FrontendController::class,'sell_2_store'])->name('selling_2');




##Frontend Routes

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth'])->name('dashboard');

require __DIR__.'/auth.php';