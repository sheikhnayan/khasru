
<?php $__env->startSection('content'); ?>

<body>
    <?php echo $__env->make('frontend.layouts.navmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section id="second-page-header">
        <div class="container">
            <div class="row">
                <div class="col">


                    <div class="header-button">
                        <button>
                            Browse Study Resource | <i class="fa fa-book" aria-hidden="true"></i>  Subjects
    
                        </button>
                    </div> 
    
                        <div class="dropdown">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col col-md-6">
                                            <div class="right-dropdown">

                                                <ul>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                </ul>
                                            </div>
                                        </div>

                                        <div class="col col-md-6">
                                            <div class="left-dropdown">

                                                <ul>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                    <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Accounting</a></li>
                                                </ul>
                                            </div>
                                        </div>


                                    </div>
                                </div>
                                <div class="dropdown-footer">
                                    <div class="row">
                                        <div class="col col-md-6">

                                            <a href="#"><i class="fa fa-long-arrow-right" aria-hidden="true"></i> Accounting</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>


                
            </div>
        </div>
    </section>

    <section id="2ndpage">
        <div class="container">
            <div class="row justify-content-center align-items-center">
                <div class="col col-lg-8">
                    <div class="first-card">
                        <div class="card">
                            <div class="card-body">
                                <h1>Exam</h1>
                                <h1>NCLEX EXAM NCLEX-PN TEST BANK WITH 725 QUESTIONS &ANSWERS & rationales-2022-2023</h1>
                                <p>NCLEX EXAM NCLEX-PN TEST BANK WITH 725 QUESTIONS &ANSWERS & rationales-2022-2023</p>
                            </div>
                        </div>
                    </div>

                    <div class="third-card">
                        <div class="card">
                            <div class="card-header">
                                <p>Preview 6 out of 392 pages</p>
                            </div>
                            <div class="card-body">
                                <embed src="https://s2.q4cdn.com/498544986/files/doc_downloads/test.pdf" type="application/pdf" width="100%" height="800" >
                            </div>
                            <div class="card-footer">
                                <p> <i class="fa fa-copyright" aria-hidden="true"></i> Report Copyright Violation</p>
                            </div>
                        </div>
                    </div>

                    <div class="forth-card">
                        <div class="card">
                            <div class="card-header">
                                <p><i class="fa fa-star kopzwart-grey" aria-hidden="true"></i>Reviews [0]</p>
                            </div>
                            <div class="card-body">
                               <div class="card-row">
                                <p>

                                    No review posted yet
                                </p>

                               </div>
                            </div>
                            
                        </div>
                    </div>

                </div>

                <div class="col col-lg-4">
                    <div class="second-card">
                        <div class="card">
                            <div class="card-body">
                                <h1>Exam Details</h1>
                                <p class="preview-page-review">
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                </p>
                                <strong class="price-preview">$16.45</strong>
                                <p>

                                    <button class="btn btn-primary"> <i class="fa fa-heart-o" aria-hidden="true"></i> Add to wishlist</button>
                                    <p class="terms">
                                        <ul>
                                            <li>
                                                <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                                Trusted by 40,000+ Students
                                            </li>
                                            <li>
                                                <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                                Money Back Guarantee 24/7
                                            </li>
                                            <li>
                                                <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                                Download is directly available
                                            </li>
                                        </ul>
                                    </p>
                                </p>

                                <div class="text-muted">
                                    <div class="row justify-content-center">
                                        <div class="col col-md-4">

                                            <p class="footer-preview">
                                                <span>
                                                    7
                                                    <i class="fa fa-eye ck" aria-hidden="true"></i>
                                                </span>
                                            </p>
                                        </div>
                                        <div class="col col-md-4">

                                            <p class="footer-preview">
                                                <span>
                                                    0
                                                    <i class="fa fa-download ck" aria-hidden="true"></i>
                                                </span>
                                            </p>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="fifth-card">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="preview-title">Specifications</h5>
                            </div>
                            <div class="card-body">
                                <div class="list-doker">
                                    <p class="card-text"></p>
                                    <div class="row">
                                        <div class="col col-md-6">
                                            institution
                                        </div>
                                        <div class="col col-md-6">
                                            <a href="">California University Of Pennsylvania </a>
                                        </div>
                                    </div>
                                    <p class="card-text"></p>
                                    <div class="row">
                                        <div class="col col-md-6">
                                            Study
                                        </div>
                                        <div class="col col-md-6">
                                            <a href="">NURSING </a>
                                        </div>
                                    </div>
                                    <p class="card-text"></p>
                                    <div class="row">
                                        <div class="col col-md-6">
                                            Course
                                        </div>
                                        <div class="col col-md-6">
                                            <a href="">NCLEXExam NCLEX PN </a>
                                        </div>
                                    </div>
                                    <p class="card-text"></p>
                                    <p class="card-text col-sm-12">Document</p>
                                    <div class="row">
                                        <div class="col col-md-6">
                                            Language
                                        </div>
                                        <div class="col col-md-6">
                                            <a href="">English </a>
                                        </div>
                                    </div>
                                    <p class="card-text"></p>
                                    <div class="row">
                                        <div class="col col-md-6">
                                            Subject
                                        </div>
                                        <div class="col col-md-6">
                                            <a href="">Health Care </a>
                                        </div>
                                    </div>
                                    <p class="card-text"></p>
                                    <div class="row">
                                        <div class="col col-md-6">
                                            Updated On
                                        </div>
                                        <div class="col col-md-6">
                                            Jun 09,2022
                                        </div>
                                    </div>
                                    <p class="card-text"></p>
                                    <div class="row">
                                        <div class="col col-md-6">
                                            Number of Pages
                                        </div>
                                        <div class="col col-md-6">
                                            392
                                        </div>
                                    </div>
                                    <p class="card-text"></p>
                                    <div class="row">
                                        <div class="col col-md-6">
                                            Type
                                        </div>
                                        <div class="col col-md-6">
                                            <a href="">Exam </a>
                                        </div>
                                    </div>
                                    <p class="card-text"></p>
                                    <div class="row">
                                        <div class="col col-md-6">
                                            Written
                                        </div>
                                        <div class="col col-md-6">
                                            <a href="">2021-2022</a>
                                        </div>
                                    </div>
                                    <p class="card-text"></p>
                                </div>
                            </div>
                            
                        </div>
                    </div>

                    <div class="sixth-card">
                        <div class="card">
                            <div class="card-header">
                                <h5>Seller Details</h5>
                            </div>
                            <div class="card-body">
                                <div class="seller-info">
                                    <div class="row">
                                        <div class="col-md-4 col-4">
                                            <img src="picture/1642752790.jpg" alt="" width="103" height="103" class="rounded-circle img-responsive user-preview-img">
                                        </div>
                                        <div class="col-md-8 col-8">
                                            <p class="username-preview">Annamaina</p>
                                            <p class="dese-preview">1573 documents uploaded</p>
                                            <p class="dese-preview">28 documents sold</p>
                                            


                                                <div class="sixth-button1">
                                                    <button><i class="fa fa-comment icko" aria-hidden="true"></i>Send Message</button>
                                                </div>
                                                <div class="sixth-button1">
                                                    <button><i class="fa fa-plus icko" aria-hidden="true"></i>Follow</button>
                                                </div>
                                            
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <p> <i class="fa fa-copyright" aria-hidden="true"></i> Report Copyright Violation</p>
                            </div>
                        </div>
                    </div>


                </div>


            </div>
        </div>
    </section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\khasru\khasru\resources\views/frontend/product.blade.php ENDPATH**/ ?>