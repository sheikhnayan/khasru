<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Subject;
use App\Models\Institute;
use App\Models\Document;
use App\Models\File as f;
use Illuminate\Http\File;
use Illuminate\Support\Facades\Storage;
use Auth;

class FrontendController extends Controller
{
    public function index()
    {
        return view('frontend.index');
    }

    public function product()
    {
        return view('frontend.product');
    }

    public function subjects()
    {
        return view('frontend.subjects');
    }

    public function subject()
    {
        return view('frontend.single_subject');
    }

    public function selling()
    {
        return view('frontend.selling');
    }

    public function sell_1()
    {
        $subjects = Subject::latest()->get();
        $institutes = Institute::latest()->get();

        return view('frontend.sell_1',compact('subjects','institutes'));
    }

    public function sell_1_store(Request $request)
    {
        // dd($request->all());
       if (!is_numeric($request->subject)) {
        $subject = new Subject;
        $subject->name = $request->subject;
        $subject->save();

        $subject_id = $subject->id; 
       }else {
        $subject = $request->subject;

        $subject_id = $subject;
       }

       if (!is_numeric($request->institute)) {
        $institute = new Institute;
        $institute->name = $request->institute;
        $institute->save();

        $institute_id = $institute->id;
       }else {
        $institute = $request->instititute;

        $institute_id = $institute;
       }

       

       $data = new Document;
       $data->institute_id = $institute_id;
       $data->user_id = Auth::user()->id;
       $data->subject_id = $subject_id;
       $data->title = $request->course_name;
       $data->save();
// dd(array_count($request->files));
//        if (count($request->files) > 1) {

        foreach ($request->files as $value) {
            foreach ($value as $key => $file) {
                # code...
                // $extension = $file->extension();
                $path = Storage::putFile('public/documents', new File($file));
    
                $file = new f;
                $file->document_id = $data->id;
                $file->file = $path;
                $file->save();
            }
        }
    //    }else {
    //         $path = $request->files->store('course/uploads', 'public');

    //         $file = new File;
    //         $file->document_id = $data->id;
    //         $file->file = $path;
    //         $file->save();
    //    }

       $categories = Subject::latest()->get();

       return redirect(route('sell_2',[$data->id]));
       
    }

    public function sell_2($id)
    {
        $data = Document::find($id)->first();

        $categories = Subject::latest()->get();

        return view('frontend.sell_2',compact('categories','data'));
    }

    public function sell_2_store(Request $request, $id)
    {
        $data = Document::find($id);
        $data->price = $request->price;
        $data->description = $request->description;
        $data->course_code = $request->course_code;
        $data->year = $request->year;
        $data->language = $request->language;
        $data->update();

        return redirect('/sell_1');
    }
}
